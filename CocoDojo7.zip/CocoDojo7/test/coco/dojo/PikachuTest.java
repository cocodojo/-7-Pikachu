/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coco.dojo;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author User
 */
public class PikachuTest {
    
    public PikachuTest() {
    }
    
    @Test
    public void testHasRoadI1() {
        Pikachu pikachu = new Pikachu();
        //Chữ I
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '2', '1', ' ', ' ', ' '},
            {' ', '3', '4', '3', ' ', ' ', ' '},
            {' ', ' ', ' ', '2', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', '4', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 2);
        pikachu.setEnd(5, 2);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadI2() {
        Pikachu pikachu = new Pikachu();
        //Chữ I nằm
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '1', '1', ' ', ' ', ' '},
            {' ', '3', '4', '3', ' ', ' ', ' '},
            {' ', ' ', '2', '2', ' ', ' ', ' '},
            {' ', ' ', '4', '1', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(1, 1);
        pikachu.setEnd(1, 2);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadU1() {
        Pikachu pikachu = new Pikachu();
        //Chữ U
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '2', '3', ' ', ' ', ' '},
            {' ', '3', '4', ' ', ' ', ' ', ' '},
            {' ', ' ', '2', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', '4', '1', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 1);
        pikachu.setEnd(1, 3);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadU2() {
        Pikachu pikachu = new Pikachu();
        //Chữ U ngược
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', '2', ' ', ' ', ' ', ' '},
            {' ', '3', '4', ' ', ' ', ' ', ' '},
            {' ', '4', '2', ' ', ' ', ' ', ' '},
            {' ', '1', ' ', '3', ' ', ' ', ' '},
            {' ', ' ', '1', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(4, 3);
        pikachu.setEnd(2, 1);
        
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadC1() {
        Pikachu pikachu = new Pikachu();
        //Chữ C
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', '2', '1', ' ', ' '},
            {' ', ' ', '4', '3', '4', '3', ' '},
            {' ', ' ', '2', ' ', ' ', '1', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(3, 2);
        pikachu.setEnd(1, 3);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadC2() {
        Pikachu pikachu = new Pikachu();
        //Chữ C ngược
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '3', '4', '3', '1', ' ', ' '},
            {' ', '4', '5', '2', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(1, 3);
        pikachu.setEnd(3, 3);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadS() {
        Pikachu pikachu = new Pikachu();
        //Chữ S
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', '3', ' ', ' '},
            {' ', '3', ' ', ' ', ' ', '4', ' '},
            {' ', '4', ' ', ' ', '6', ' ', ' '},
            {' ', '1', '6', '5', '2', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 5);
        pikachu.setEnd(3, 1);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadZ() {
        Pikachu pikachu = new Pikachu();
        //Chữ Z
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '3', ' ', '4', ' ', ' ', ' '},
            {' ', '4', ' ', '3', '6', ' ', ' '},
            {' ', '1', '6', '5', '2', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 1);
        pikachu.setEnd(3, 3);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadN1() {
        Pikachu pikachu = new Pikachu();
        //Chữ N
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '3', ' ', '4', ' ', ' ', ' '},
            {' ', ' ', ' ', '1', '6', ' ', ' '},
            {' ', ' ', '6', '4', '2', ' ', ' '},
            {' ', '5', '3', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(5, 1);
        pikachu.setEnd(1, 2);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadN2() {
        Pikachu pikachu = new Pikachu();
        //Chữ N ngược
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '3', ' ', '4', ' ', ' ', ' '},
            {' ', '4', ' ', ' ', '6', ' ', ' '},
            {' ', '1', '6', '5', '2', ' ', ' '},
            {' ', ' ', '3', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(1, 2);
        pikachu.setEnd(4, 3);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
       
    @Test
    public void testHasRoadL1() {
        Pikachu pikachu = new Pikachu();
        //Chữ L
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '3', ' ', '4', ' ', ' ', ' '},
            {' ', '4', ' ', '2', ' ', ' ', ' '},
            {' ', '1', ' ', ' ', '5', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        
        pikachu.setBoard(board);
        pikachu.setStart(1, 2);
        pikachu.setEnd(4, 4);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadL2() {
        Pikachu pikachu = new Pikachu();
        //Chữ L nguoc
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '4', '2', ' ', ' ', ' '},
            {' ', '3', ' ', '5', ' ', ' ', ' '},
            {' ', '4', '1', ' ', ' ', ' ', ' '},
            {' ', '5', ' ', ' ', '2', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 3);
        pikachu.setEnd(4, 1);
        
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoad71() {
        Pikachu pikachu = new Pikachu();
        //Số 7
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', ' ', '2', ' ', ' ', ' '},
            {' ', '3', ' ', '4', ' ', ' ', ' '},
            {' ', '4', ' ', '2', ' ', ' ', ' '},
            {' ', '5', '1', '5', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(1, 1);
        pikachu.setEnd(4, 2);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoad72() {
        Pikachu pikachu = new Pikachu();
        //Số 7 ngược
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '2', ' ', '1', ' ', ' ', ' '},
            {' ', '3', ' ', '4', ' ', ' ', ' '},
            {' ', '4', ' ', '2', ' ', ' ', ' '},
            {' ', '5', '1', '5', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(4, 2);
        pikachu.setEnd(1, 3);
        boolean expec = true;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadFail1() {
        Pikachu pikachu = new Pikachu();
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '3', '4', '3', ' ', ' ', ' '},
            {' ', '4', '5', '2', ' ', ' ', ' '},
            {' ', ' ', '1', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(3, 1);
        pikachu.setEnd(2, 2);
        boolean expec = false;
        assertEquals(expec, pikachu.hasRoad());
    }
        
    @Test
    public void testHasRoadFail2() {
        Pikachu pikachu = new Pikachu();
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '3', '4', '3', ' ', ' ', ' '},
            {' ', '4', '5', '2', ' ', ' ', ' '},
            {' ', ' ', '1', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 1);
        pikachu.setEnd(2, 3);
        boolean expec = false;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadFail3() {
        Pikachu pikachu = new Pikachu();
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '4', '5', '2', ' ', ' ', ' '},
            {' ', '1', '4', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 1);
        pikachu.setEnd(2, 3);
        boolean expec = false;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadFail4() {
        Pikachu pikachu = new Pikachu();
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '4', ' ', '1', ' ', ' ', ' '},
            {' ', '4', '5', '2', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 1);
        pikachu.setEnd(2, 3);
        boolean expec = false;
        assertEquals(expec, pikachu.hasRoad());
    }
    
    @Test
    public void testHasRoadFail5() {
        Pikachu pikachu = new Pikachu();
        char[][] board = {
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', '1', '5', '2', ' ', ' ', ' '},
            {' ', '4', ' ', '1', ' ', ' ', ' '},
            {' ', '4', '5', '2', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '},
            {' ', ' ', ' ', ' ', ' ', ' ', ' '}
        };
        pikachu.setBoard(board);
        pikachu.setStart(2, 1);
        pikachu.setEnd(2, 1);
        boolean expec = false;
        assertEquals(expec, pikachu.hasRoad());
    }
}
