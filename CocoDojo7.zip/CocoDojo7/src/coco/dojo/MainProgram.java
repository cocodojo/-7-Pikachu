/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coco.dojo;

/**
 *
 * @author User
 */
public class MainProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
