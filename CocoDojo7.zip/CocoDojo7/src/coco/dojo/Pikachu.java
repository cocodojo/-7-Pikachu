/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coco.dojo;

import java.util.List;

/**
 *
 * @author User
 */
public class Pikachu {

    public static final int BOARD_COLUMNS = 7;
    public static final int BOARD_ROWS = 7;
    public static final char EMPTY_PIKACHU = ' ';
    private char[][] board = new char[BOARD_ROWS][BOARD_COLUMNS];
    
    private int fromCol;
    private int fromRow;
    private int toCol;
    private int toRow;

    public void setStart(int fromRow, int fromCol) {
        this.fromCol = fromCol;
        this.fromRow = fromRow;
    }

    public void setEnd(int toRow, int toCol) {
        this.toCol = toCol;
        this.toRow = toRow;
    }

    //Kiểm tra xem có đường đi theo cột dọc không?
    private boolean hasVPath(int row1, int row2, int col) {
        for (int row = row1; row <= row2; row++) {
            if (isPikachu(row, col)) {
                return false;
            }
        }
        return true;
    }

    //Kiểm tra xem có đường đi theo hàng ngang không?
    private boolean hasHPath(int row, int col1, int col2) {
        for (int col = col1; col <= col2; col++) {
            if (isPikachu(row, col)) {
                return false;
            }
        }
        return true;
    }

    public boolean hasRoad() {
        changePosition();

        if (fromCol == toCol && fromRow == toRow) {
            return false;
        }
        if (getPikachu(fromRow, fromCol) != getPikachu(toRow, toCol)
                || !isPikachu(fromRow, fromCol)) {
            return false;
        }

        //Chu I:
        if (fromCol == toCol) {
            if (hasVPath(fromRow + 1, toRow - 1, fromCol)) {
                return true;
            }
        }

        //Chu I nam ngang:
        if (fromRow == toRow) {
            if (hasHPath(fromRow, fromCol + 1, toCol - 1)) {
                return true;
            }
        }

        if (fromCol < toCol) {
            //Chu L:
            if (hasVPath(fromRow + 1, toRow, fromCol)
                    && hasHPath(toRow, fromCol, toCol - 1)) {
                return true;
            }

            //So 7:
            if (hasHPath(fromRow, fromCol + 1, toCol)
                    && hasVPath(fromRow, toRow - 1, toCol)) {
                return true;
            }

            //Chu S nguoc:
            //Duyệt và dừng khi tìm được đường chữ Z đầu tiên
            for (int c = fromCol + 1; c < toCol; c++) {
                if (hasHPath(fromRow, fromCol + 1, c)
                        && hasVPath(fromRow, toRow, c)
                        && hasHPath(toRow, c, toCol - 1)) {
                    return true;
                }
            }

            //Chu N nguoc:
            //Duyệt và dừng khi tìm được đường chữ N ngược đầu tiên
            for (int r = fromRow + 1; r < toRow; r++) {
                if (hasVPath(fromRow + 1, r, fromCol)
                        && hasHPath(r, fromCol, toCol)
                        && hasVPath(r, toRow - 1, toCol)) {
                    return true;
                }
            }
        }

        if (fromCol > toCol) {
            //Chu L nguoc:
            if (hasVPath(fromRow + 1, toRow - 1, fromCol)
                    && hasHPath(toRow, toCol + 1, fromCol)) {
                return true;
            }

            //So 7 nguoc:
            if (hasHPath(fromRow, toCol, fromCol - 1)
                    && hasVPath(fromRow, toRow - 1, toCol)) {
                return true;
            }

            //Chu S:
            //Duyệt và dừng khi tìm được đường chữ S đầu tiên
            for (int c = fromCol - 1; c > toCol; c--) {
                if (hasHPath(fromRow, c, fromCol - 1)
                        && hasVPath(fromRow, toRow, c)
                        && hasHPath(toRow, toCol + 1, c)) {
                    return true;
                }
            }

            //Chu N:
            //Duyệt và dừng khi tìm được đường chữ N đầu tiên
            for (int r = fromRow + 1; r < toRow; r++) {
                if (hasVPath(fromRow + 1, r, fromCol)
                        && hasHPath(r, toCol, fromCol)
                        && hasVPath(r, toRow - 1, toCol)) {
                    return true;
                }
            }

        }

        //Chu C:
        //Duyệt và dừng khi tìm được đường chữ C đầu tiên
        for (int c = fromCol - 1; c >= 0; c--) {
            if (hasHPath(fromRow, c, fromCol - 1)
                    && hasVPath(fromRow, toRow, c)
                    && hasHPath(toRow, c, toCol - 1)) {
                return true;
            }
        }

        //Chu C nguoc:
        //Duyệt và dừng khi tìm được đường chữ C ngược đầu tiên
        for (int c = fromCol + 1; c < BOARD_COLUMNS; c++) {
            if (hasHPath(fromRow, fromCol + 1, c)
                    && hasVPath(fromRow, toRow, c)
                    && hasHPath(toRow, toCol + 1, c)) {
                return true;
            }
        }
        
        int col1 = fromCol;
        int col2 = toCol;
        
        if (fromCol>toCol) {
            col1 = toCol;
            col2 = fromCol;
        }
        
        //Chu U:
        //Duyệt và dừng khi tìm được đường chữ U đầu tiên
        for (int r = fromRow + 1; r < BOARD_ROWS; r++) {
            if (hasVPath(fromRow + 1, r, fromCol)
                    && hasHPath(r, col1, col2)
                    && hasVPath(toRow + 1, r, toCol)) {
                return true;
            }
        }

        //Chu U nguoc:
        //Duyệt và dừng khi tìm được đường chữ U ngược đầu tiên
        for (int r = fromRow - 1; r >= 0; r--) {
            if (hasVPath(r, fromRow - 1, fromCol)
                    && hasHPath(r, col1, col2)
                    && hasVPath(r, toRow - 1, toCol)) {
                return true;
            }
        }

        return false;
    }

    void setBoard(char[][] board) {
        this.board = board;
    }

    private void changePosition() {
        //Chuyển điểm đầu có dòng < dòng của điểm cuối
        if (fromRow > toRow) {
            int tmpX = fromCol;
            fromCol = toCol;
            toCol = tmpX;

            int tmpY = fromRow;
            fromRow = toRow;
            toRow = tmpY;
            //Chuyển điểm đầu có cột < cột của điểm cuối (nếu hai điểm cùng dòng)    
        } else if (fromRow == toRow) {
            if (fromCol > toCol) {
                int tmpX = fromCol;
                fromCol = toCol;
                toCol = tmpX;

                int tmpY = fromRow;
                fromRow = toRow;
                toRow = tmpY;
            }
        }
    }

    private boolean isPikachu(int row, int col) {
        if (board[row][col] == EMPTY_PIKACHU || board[row][col] == '\0') {
            return false;
        }
        return true;
    }

    private char getPikachu(int row, int col) {
        return board[row][col];
    }
}
